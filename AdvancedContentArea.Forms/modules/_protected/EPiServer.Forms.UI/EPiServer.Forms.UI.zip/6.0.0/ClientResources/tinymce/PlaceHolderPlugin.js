
/**
 * TinyMCE Placeholder Plugin for EPiServer Forms
 * 
 * This plugin adds a dropdown menu button to the TinyMCE editor that allows users to insert
 * form field placeholders into rich text content. The placeholders are dynamically retrieved
 * based on the current form element context.
 * 
 * Features:
 * - Fetches placeholder settings from the server on initialization
 * - Dynamically loads available placeholders based on the current content context
 * - Inserts placeholders in the format "::PlaceholderName::" when selected
 * 
 * Dependencies:
 * - TinyMCE editor instance
 * - Server-side endpoint for placeholder settings and data
 * - forms_ui_base_url parameter must be configured in TinyMCE settings
 */
tinymce.PluginManager.add("placeholder", function (editor) {

    var clientResources = editor.getParam("forms_ui_client_resources_url");
    editor.ui.registry.addIcon('placeholder_icon', '<img src="' + clientResources + '/tinymce/placeholder_icon.png" />');

    // get base url which send from server.
    var formsUIBaseUrl = editor.getParam("forms_ui_base_url");

    if (!formsUIBaseUrl) {
        console.error("Cannot load Forms placeholder plugin.");
        return;
    }

    // Cache key for session storage
    var RESOURCES_CACHE_KEY = 'epi_forms_editview';
    var formsEditViewResources = null;

    try {
        // Try to get from session storage first
        var resourceString = sessionStorage.getItem(RESOURCES_CACHE_KEY);
        if (resourceString) {
            formsEditViewResources = JSON.parse(resourceString);
        } else {
            // If not in cache, parse from DOM and cache it
            var resourcesContainer = document.getElementById("episerver-resources-container");
            if (resourcesContainer && resourcesContainer.dataset.epiResources) {
                var resources = JSON.parse(resourcesContainer.dataset.epiResources);
                // Only cache if we have the required data
                if (resources.episerver.forms.editview) {
                    formsEditViewResources = resources.episerver.forms.editview;
                    sessionStorage.setItem(RESOURCES_CACHE_KEY, JSON.stringify(formsEditViewResources));
                };
            }

        }
    } catch (ex) {
        // Clear invalid cache if exists
        sessionStorage.removeItem(RESOURCES_CACHE_KEY);
    }

    if (!formsEditViewResources) {
        console.error("Cannot load Forms localized resources.");
        return;
    }

    editor.ui.registry.addMenuButton('placeholder', {
        text: formsEditViewResources.insertplaceholder,
        icon: 'placeholder_icon',
        fetch: function (callback) {

            var contentId = editor.getParam("contentLink");
            if (!contentId) {
                console.error("Cannot load Forms placeholders: missing contentLink.");
                callback([]);

                return;
            }

            fetch(formsUIBaseUrl + "Stores/formselement/" + contentId + "?query=GetPlaceholders")
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.json();
                })
                .then(function (items) {
                    var menuItems = items.map(function (item) {
                        return {
                            type: 'menuitem',
                            text: item.name,
                            onAction: function () {
                                editor.insertContent("::" + item.name + "::");
                            }
                        };
                    });

                    if (menuItems.length === 0) {
                        callback([{
                            type: 'menuitem',
                            text: formsEditViewResources.noplaceholdersavailable,
                            onAction: function () { }
                        }]);
                    } else {
                        callback(menuItems);
                    }
                });
        }
    });
});
