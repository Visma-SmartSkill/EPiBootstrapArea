define("epi-forms/widget/ExportSelectorMenu", [
// dojo
"dojo/_base/declare",
// dijit
"dijit/MenuItem",
// epi-addons
"epi-forms/widget/SelectorMenuBase",
// resources
"epi/i18n!epi/cms/nls/episerver.forms.formdataview"], function (
// dojo
declare,
// dijit
MenuItem,
// epi-addons
SelectorMenuBase,
// resources
resources) {
  // module:
  //      epi-forms/widget/ExportSelectorMenu
  // summary:
  //      Export selector menu widget.
  // tags:
  //      public

  return declare([SelectorMenuBase], {
    headingText: resources["export"],
    createMenuItem: function createMenuItem(/*Object*/exporter) {
      // summary:
      //      Create an instance of 'dijit/MenuItem' from the given data object.
      // item: [Object]
      //      Data object that used to build a menu item widget.
      // returns: [Object]
      //      Returns an instance of 'dijit/MenuItem' class.
      // tags:
      //      public, extensions

      return new MenuItem({
        label: exporter.name,
        title: exporter.description,
        onClick: function onClick() {
          typeof exporter.onExport === "function" && exporter.onExport(exporter);
        }
      });
    }
  });
});