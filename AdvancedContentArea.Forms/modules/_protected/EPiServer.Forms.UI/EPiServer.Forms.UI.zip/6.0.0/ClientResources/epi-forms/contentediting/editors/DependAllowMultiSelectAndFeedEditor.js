define("epi-forms/contentediting/editors/DependAllowMultiSelectAndFeedEditor", [
// dojo
"dojo/_base/array", "dojo/_base/declare", "dojo/_base/lang", "dojo/dom-style", "dojo/when",
// epi
"epi/dependency", "epi-cms/contentediting/command/Editing",
// epi-forms
"epi-forms/contentediting/editors/FeedSelectionEditor", "epi-forms/contentediting/editors/AllowMultiSelectCheckbox", "epi-forms/contentediting/editors/OptionListEditor", "epi-forms/ModuleSettings"], function (
// dojo
array, declare, lang, domStyle, when,
// epi
dependency, EditingCommands,
// epi-forms,
FeedSelectionEditor, AllowMultiSelectCheckbox, OptionListEditor, ModuleSettings) {
  // module:
  //      epi-forms/contentediting/editors/DependAllowMultiSelectEditor
  // summary:
  //
  // tags:
  //      public

  return declare([OptionListEditor], {
    _store: null,
    _contentViewModel: null,
    _allowMultiSelectPropertyName: "allowMultiSelect",
    _feedPropertyName: "feed",
    // =======================================================================
    // Public, overrided stubs
    // =======================================================================

    postCreate: function postCreate() {
      var _this$_contentViewMod;
      // tags:
      //      protected, extensions

      var registry = dependency.resolve("epi.storeregistry");
      this._store = registry.get("epi.cms.content.light");

      // this editor depend on [Allow Multiple Select] property,
      // if [Allow Multiple Select] property is set to true then allow multi selection on this editor,
      // otherwise allow single selection
      this.isMultiSelect = (_this$_contentViewMod = this._contentViewModel) === null || _this$_contentViewMod === void 0 ? void 0 : _this$_contentViewMod.getProperty(this._allowMultiSelectPropertyName);
      this.connect(FeedSelectionEditor.prototype, "onFeedValueChange", lang.hitch(this, function (propertyName, value) {
        this._setOptionItemsEditorDisplay(value == ModuleSettings.useManualInput);
      }));
      this.connect(AllowMultiSelectCheckbox.prototype, "onFeedValueChange", lang.hitch(this, function (propertyName, value) {
        this.isMultiSelect = value;
        // reset checked items if the property change from true to false
        if (!value) {
          array.forEach(this.model.get("items"), function (existingItem, i) {
            existingItem.checked = false;
            this.model.saveItem(existingItem, i);
          }, this);
        }
      }));
      this.inherited(arguments);
    },
    startup: function startup() {
      this.inherited(arguments);

      // Case 1: All Properties mode.
      // FormsUIModule.js injects _contentViewModel before widgets are created,
      // and the widget is already in the DOM when startup() runs.
      var contentViewModel = this._contentViewModel;
      if (contentViewModel) {
        this._applyFeedVisibility(contentViewModel);
        return;
      }

      // Case 2: Visual Builder mode — onPreviewReady already fired before startup().
      // The widget is not yet in the DOM at this point (React commits after startup),
      // so defer to allow React to place the widget in the DOM first.
      var editingContext = dependency.resolve("epi.forms.EditingContext");
      contentViewModel = editingContext && editingContext.getViewModel();
      if (contentViewModel) {
        this.defer(lang.hitch(this, this._applyFeedVisibility, contentViewModel));
        return;
      }
    },
    _applyFeedVisibility: function _applyFeedVisibility(contentViewModel) {
      var feedValue = contentViewModel.getProperty(this._feedPropertyName);
      this._setOptionItemsEditorDisplay(feedValue == ModuleSettings.useManualInput);
    },
    // =======================================================================
    // Private stubs
    // =======================================================================

    _setOptionItemsEditorDisplay: function _setOptionItemsEditorDisplay(show) {
      // summary:
      //      show/hide OptionItems editor.
      // tags:
      //      private

      // In Visual Builder mode the editor is wrapped in multiple single-child divs
      // before the actual property row (which contains the label as a sibling).
      // Walk up through single-child wrappers to find the real property container.
      var node = this.domNode.parentNode;
      if (!node) {
        return;
      }
      while (node.childElementCount === 1 && node.parentNode) {
        node = node.parentNode;
      }
      domStyle.set(node, "display", show ? "" : "none");
    },
    _getGridDefinition: function _getGridDefinition() {
      // summary:
      //      Returns grid's columns definition.
      // tags:
      //      override

      var columns = this.inherited(arguments);
      // display name of the image instead of ID
      lang.mixin(columns.source, {
        renderCell: lang.hitch(this, function (item, value, node, options) {
          if (!item.source) {
            return;
          }
          when(this._store.get(item.source), lang.hitch(this, function (content) {
            node.innerHTML = content.name;
          }));
        })
      });
      return columns;
    }
  });
});