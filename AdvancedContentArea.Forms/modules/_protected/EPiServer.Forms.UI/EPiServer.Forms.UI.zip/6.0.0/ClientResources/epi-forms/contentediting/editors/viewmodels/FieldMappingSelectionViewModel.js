define("epi-forms/contentediting/editors/viewmodels/FieldMappingSelectionViewModel", [
// dojo
"dojo/_base/declare", "dojo/Deferred", "dojo/when",
// epi
"epi/dependency", "epi-cms/contentediting/viewmodel/_ViewModelMixin"], function (
// dojo
declare, Deferred, when,
// epi
dependency, _ViewModelMixin) {
  // module:
  //      epi-forms/contentediting/editors/viewmodels/FieldMappingSelectionViewModel
  // summary:
  //      View model for 'epi-forms/contentediting/editors/ChoiceWithEditor' widget
  // tags:
  //      public

  return declare([_ViewModelMixin], {
    postscript: function postscript() {
      this.inherited(arguments);
      var registry = dependency.resolve("epi.storeregistry");
      this._externalFeedStore = this._externalFeedStore || registry.get("epi-forms.externalfeed");
    },
    getItems: function getItems(/*Object*/searchConditions) {
      // summary:
      //      Get feed item collection.
      // searchConditions: [Object]
      //
      // returns: [Array]
      //      Feed items
      // tags:
      //      public

      var deferred = new Deferred(),
        params = {
          id: "getFeedItems",
          feedSelector: searchConditions.key
        };
      when(this._externalFeedStore.query(params), function (/*Array*/items) {
        deferred.resolve(items);
      });
      return deferred;
    }
  });
});