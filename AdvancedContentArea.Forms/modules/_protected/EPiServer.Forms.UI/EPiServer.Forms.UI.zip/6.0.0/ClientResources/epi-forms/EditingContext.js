define("epi-forms/EditingContext", [
// dojo
"dojo/_base/declare", "dojo/Stateful",
// epi
"epi/shell/DestroyableByKey",
// epi-cms
"epi-cms/_ContentContextMixin"], function (
// dojo
declare, Stateful,
// epi
DestroyableByKey,
// epi-cms
_ContentContextMixin) {
  return declare([Stateful, DestroyableByKey, _ContentContextMixin], {
    // summary:
    //      The editing context provides contextual information for editing operations.
    //
    // tags:
    //      internal

    _viewModel: null,
    postscript: function postscript() {
      this.inherited(arguments);
    },
    setViewModel: function setViewModel(viewModel) {
      this._viewModel = viewModel;
    },
    getViewModel: function getViewModel() {
      return this._viewModel;
    }
  });
});